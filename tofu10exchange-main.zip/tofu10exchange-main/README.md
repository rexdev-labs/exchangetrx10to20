# Tofu10Exchange contract

TofuDeFi10 or TOFU10 token (TRON Token ID: 1003475) is an auxiliary TRC10 token interchangeable with main TofuDeFi TRC20 token(TOFU). You can send it with much lower fees compared to TOFU token because transfer of TRC10 tokens does not consume Energy, only Bandwidth. 

This repository contains source code of Tofu10Exchange contract which is the main contract to swap between TOFU and TOFU10.
